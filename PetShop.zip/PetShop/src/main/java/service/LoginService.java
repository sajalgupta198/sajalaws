package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import repository.UserRepository;


@Service
public class LoginService {

@Autowired
UserRepository repo;

	
	public void RegisterUser(LoginService loginservice)
	{
		repo.save(loginservice);		
	}


	
	  public String login(String username,String password) {
	   
		  LoginService d=repo.findByEmail(username);
		  if(d.getPassword().equals(password))
		  {
			  return "LogInSuccess";  
		  }		  else {
			  return "failed";
		  }
	  }
	  
	  public String adminLogin(String username,String  password) {
		  LoginService d=repo.findByEmail(username);
		  if(d.getUsername().equals("Admin"))
		  {
			  if(d.getPassword().equals(password))
			  {
				  return "AdminLogInSuccess";
			  }else {
				  return "failed";
			  }
			  
		  }else {
			  return "failed";
		  }
	  }
	  
}



