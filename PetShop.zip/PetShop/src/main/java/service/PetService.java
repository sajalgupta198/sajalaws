package service;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.Pet;
import repository.PetRepository;

@Service
public class PetService
{
	@Autowired
	PetRepository repo;
	
	public Pet savePet(Pet p)
	{
		return repo.save(p);
	}
	
	public List<Pet> savePets(List<Pet> list)
	{
		return repo.saveAll(list);
	}
	
	public List<Pet> getPets()
	{
		return repo.findAll();
	}
	
	public Pet getPetById(int id)
	{
		return repo.findById(id).orElse(null);
	}
	
	public Pet getPetByType(String type)
	{
		return repo.findPetByType(type);
	}
	
	public String deletePet(int id)
	{
		repo.deleteById(id);
		return "Pet Deleted: "+id;
	}
	
	public Pet updatePetInfo(Pet p)
	{
		Pet existingPet = repo.findById(p.getPid()).orElse(null);
		existingPet.setType(p.getType());
		existingPet.setAge(p.getAge());
		existingPet.setLocation(p.getLocation());
		existingPet.setCity(p.getCity());
		existingPet.setState(p.getState());
		existingPet.setCountry(p.getCountry());
		existingPet.setPrice(p.getPrice());
		existingPet.setStatus(p.getStatus());
		return repo.save(existingPet);
	}
}
