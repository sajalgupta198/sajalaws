package repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import service.LoginService;

@Repository
public interface UserRepository extends JpaRepository<LoginService,String> {

	LoginService findByEmail(String username);

	/* LogInData findByUsernameAndPassword(String username, String password); */

}
