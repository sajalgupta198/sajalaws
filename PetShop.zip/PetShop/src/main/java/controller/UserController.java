package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import service.LoginService;

@Controller
public class UserController {

	@Autowired
	LoginService sl;

		@RequestMapping(value="/register",method=RequestMethod.POST)
		public String register(DataLayer datalayer)
		{
			sl.RegisterUser(datalayer);
			return "Registered";
		}
		
		
		
		  @PostMapping("/login") 
		  public String loginUser(@RequestParam String username,@RequestParam String  password){
			  return sl.login(username,password);
		  
		  }
		  
		  @PostMapping("/adminlogin") 
		  public String adminLogin(@RequestParam String username,@RequestParam String  password){
			  return sl.adminLogin(username,password);
		  }
}
