package controller;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import model.Pet;
import service.PetService;


@RestController
public class PetController
{
	@Autowired
	PetService petservice;
	
	@PostMapping("/addPet")
	public Pet addPet(@RequestBody Pet petinfo)
	{
		return petservice.savePet(petinfo);
	}
	
	@GetMapping("/pets")
	public List<Pet> findAllPet()
	{
		return petservice.getPets();
	}
	
	@GetMapping("petbyid/{id}")
	public Pet findPetById(@PathVariable int id)
	{
		return petservice.getPetById(id);
	}
	
	@GetMapping("/petbytype/{type}")
	public Pet findPetByType(@PathVariable String type)
	{
		return petservice.getPetByType(type);
	}
	
	@PutMapping("/update")
	public Pet updatePet(@RequestBody Pet p)
	{
		return petservice.updatePetInfo(p);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deletePet(@PathVariable int id)
	{
		return petservice.deletePet(id);
	}
	
}